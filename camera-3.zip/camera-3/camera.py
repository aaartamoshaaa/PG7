import pygame
import os


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)
    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    return image


def load_level(filename):
    filename = "data/" + filename
    # читаем уровень, убирая символы перевода строки
    with open(filename, 'r') as mapFile:
        level_map = [line.strip() for line in mapFile]

    # и подсчитываем максимальную длину
    max_width = max(map(len, level_map))

    # дополняем каждую строку пустыми клетками ('.')
    return list(map(lambda x: x.ljust(max_width, '.'), level_map))


class Tile(pygame.sprite.Sprite):
    tile_images = {
        'wall': pygame.transform.scale(load_image('box.png'), (50, 50)),
        'empty': pygame.transform.scale(load_image('grass.png'), (50, 50))
    }

    def __init__(self, tile_type, pos_x, pos_y, all_sprites, tiles_group):
        super().__init__(tiles_group, all_sprites)
        self.image = Tile.tile_images[tile_type]
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.rect = self.image.get_rect().move(
            50 * pos_x, 50 * pos_y)
        self.tile_type = tile_type

    def shift_tile(self, pos_x: int, pos_y: int):
        self.pos_x += pos_x
        self.pos_y += pos_y
        self.rect = self.image.get_rect(
            bottomright=(50 * (self.pos_x + 1),
                         50 * (self.pos_y + 1)))


class Field:
    def __init__(self, all_sprites, player_group, tiles_group, map):
        self.images = []
        self.player = None
        self.current_cell = None
        self.lambd = [0, 0]
        self.generate_level(load_level(map), all_sprites, player_group,
                            tiles_group)

    def generate_level(self, level, all_sprites, player_group, tiles_group):
        for y in range(len(level)):
            self.images.append([])
            for x in range(len(level[y])):
                if level[y][x] == '.':
                    image = Tile('empty', y, x, all_sprites, tiles_group)
                elif level[y][x] == '#':
                    image = Tile('wall', y, x, all_sprites, tiles_group)
                elif level[y][x] == '@':
                    image = Tile('empty', y, x, all_sprites, tiles_group)
                    self.player = Player(y, x, all_sprites, player_group)
                    self.current_cell = [y, x]
                self.images[y].append(image)

    def get_player(self):
        return self.player

    def move(self, event):
        x, y = self.current_cell[0], self.current_cell[1]
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT and self.images[x - 1][
                y].tile_type != 'wall' \
                    and x != 0:
                self.current_cell[0] -= 1
                self.lambd[0] += 1
            elif event.key == pygame.K_RIGHT and x != 10:
                if self.images[x + 1][y].tile_type != 'wall':
                    self.current_cell[0] += 1
                    self.lambd[0] -= 1
            elif event.key == pygame.K_UP and self.images[x][
                y - 1].tile_type != 'wall' \
                    and y != 0:
                self.current_cell[1] -= 1
                self.lambd[1] += 1
            elif event.key == pygame.K_DOWN and y != 10:
                if self.images[x][y + 1].tile_type != 'wall':
                    self.current_cell[1] += 1
                    self.lambd[1] -= 1
            self.shift_tiles(*self.lambd)

    def shift_tiles(self, pos_x: int, pos_y: int) -> None:
        self.lambd = [0, 0]
        for line in self.images:
            for tile in line:
                tile.shift_tile(pos_x, pos_y)


class Player(pygame.sprite.Sprite):
    player_image = load_image('mario.png')

    def __init__(self, pos_x, pos_y, player_group, all_sprites):
        super().__init__(player_group, all_sprites)
        self.image = Player.player_image
        self.rect = self.image.get_rect().move(
            50 * pos_x + 15, 50 * pos_y + 5)

    def move_player(self, current_cell):
        self.rect = self.image.get_rect().move(
            50 * current_cell[0] + 15, 50 * current_cell[1] + 5)


def start_screen():
    pygame.init()
    size = width, height = 550, 550
    screen = pygame.display.set_mode(size)
    fon = pygame.transform.scale(load_image('fon.jpg'), (width, height))
    screen.blit(fon, (0, 0))
    font = pygame.font.Font(None, 30)
    game_over = font.render("ЗАСТАВКА", True, pygame.Color('black'))
    screen.blit(game_over, (30, 30))
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN or \
                    event.type == pygame.MOUSEBUTTONDOWN:
                return True
        pygame.display.flip()


def main():
    while True:
        map = input('Выберите карту (map_1, map_2): ')
        if map in ["map_1", "map_2"]:
            break
    if not start_screen():
        return
    all_sprites = pygame.sprite.Group()
    tiles_group = pygame.sprite.Group()
    player_group = pygame.sprite.Group()
    field = Field(all_sprites, player_group, tiles_group, str(map) + '.txt')
    groups = [tiles_group, player_group]
    pygame.init()
    size = 550, 550
    screen = pygame.display.set_mode(size)
    clock = pygame.time.Clock()
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            field.move(event)
        for group in groups:
            group.update()
            group.draw(screen)
        pygame.display.flip()
        clock.tick(50)
    pygame.quit()


if __name__ == '__main__':
    main()
